define(['durandal/app','knockout','plugins/router'], function (app,ko,router) {
    return {};
}); 