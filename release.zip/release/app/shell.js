define(['plugins/router', 'durandal/app', 'knockout'], function (router, app, ko) {
    return {
        data: {
            userName: ko.observable('')
        },
        router: router,
        routersModel: ko.observableArray(),
        search: function () {
            //It's really easy to show a message box.
            //You can add custom options too. Also, it returns a promise for the user's response.
            app.showMessage('Search not yet implemented...');
        },
        activate: function () {
            this.data.userName(appConfig.app.userInfo.Data);

            router.map(appConfig.app.routeList).buildNavigationModel();

            var tmpArr = new Array();
            appConfig.app.routeTypeArr.forEach(function (item) {
                tmpArr.push(router.routes.filter(function (val) {
                    if (val.hash == '#') return false;
                    return val.type == item;
                }))
            })
            this.routersModel(tmpArr);

            return router.activate();
        },
        attached: function () {
            initApp.SmartActions();
            initApp.leftNav();
            initApp.domReadyMisc();
        },
        logoutClick: function () {
            // ask verification
            $.SmartMessageBox({
                title: "<i class='fa fa-sign-out txt-color-orangeDark'></i> 退出 <span class='txt-color-orangeDark'><strong>" + $('#show-shortcut').text() + "</strong></span> ?",
                content: "您的账户即将退出",
                buttons: '[取消][确定]'

            }, function (ButtonPressed) {
                // $.root_.addClass('animated fadeOutUp');
                // $.root_.addClass('animated fadeOutUp');
                if (ButtonPressed == "确定") {
                    router.deactivate();
                    router.reset();
                    app.setRoot('login');
                    window.location.hash = "#applying";
                }
            });

        },
        //修改密码
        changePassWord:function(){
            router.navigate("#changePassWord");
        },
        toggleMenu: function () {
            if (!$.root_.hasClass("menu-on-top")) {
                $('html').toggleClass("hidden-menu-mobile-lock");
                $.root_.toggleClass("hidden-menu");
                $.root_.removeClass("minified");
                //} else if ( $.root_.hasClass("menu-on-top") && $.root_.hasClass("mobile-view-activated") ) {
                // suggested fix from Christian Jäger	
            } else if ($.root_.hasClass("menu-on-top") && $(window).width() < 979) {
                $('html').toggleClass("hidden-menu-mobile-lock");
                $.root_.toggleClass("hidden-menu");
                $.root_.removeClass("minified");
            }
        }
    };
});