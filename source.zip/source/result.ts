 
import {JsonObject, JsonMember, TypedJSON} from  "typedjson"
 

